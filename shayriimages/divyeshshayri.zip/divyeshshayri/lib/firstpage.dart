import 'package:divyeshshayri/model.dart';
import 'package:divyeshshayri/secondpage.dart';
import 'package:flutter/material.dart';

class firstpage extends StatefulWidget {
  const firstpage({Key? key}) : super(key: key);

  @override
  State<firstpage> createState() => _firstpageState();
}

class _firstpageState extends State<firstpage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            Text("||**||**||........................Shayri........................||**||**||"),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: Model().names.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 10,
            margin: EdgeInsets.all(10),
            color: Colors.white,
            shadowColor: Colors.blue,
            child: ListTile(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return secondpage(index);
                  },
                ));
              },
              title: Text(
                Model().names[index],
                style: TextStyle(color: Colors.black, fontSize: 25),
              ),
              trailing: IconButton(onPressed: () {
                
              }, icon: Icon(Icons.arrow_forward_ios)),
              leading: Image(
                  image: AssetImage(Model().images[index]),
                  fit: BoxFit.fill,
                  height: 90,
                  width: 90),
            ),
          );
        },
        // itemCount: names.length,
      ),
    );
  }
}
