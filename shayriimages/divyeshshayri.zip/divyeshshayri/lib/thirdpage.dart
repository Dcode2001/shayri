import 'package:flutter/material.dart';

class thirdpage extends StatefulWidget {

  List<String> shayriList;
  int index;

  thirdpage(this.shayriList, this.index);

  @override
  State<thirdpage> createState() => _thirdpageState();
}

class _thirdpageState extends State<thirdpage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(
      title: Text("${widget.index + 1} / ${widget.shayriList.length}"),centerTitle: true),

    body: Container(margin: EdgeInsets.all(20),alignment: Alignment.center,color: Colors.deepPurple,height: 800,width: 600,3),
    );
  }
}
