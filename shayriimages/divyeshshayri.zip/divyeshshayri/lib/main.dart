import 'package:divyeshshayri/firstpage.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: firstpage(),
  ));
}
