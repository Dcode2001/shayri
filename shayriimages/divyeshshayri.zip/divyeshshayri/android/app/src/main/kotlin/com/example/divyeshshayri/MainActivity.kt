package com.example.divyeshshayri

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
